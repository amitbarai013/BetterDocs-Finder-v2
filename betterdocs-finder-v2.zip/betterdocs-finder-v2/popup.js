// popup.js — BetterDocs Finder v3
//
// Detection pipeline (stops at first success):
//   1. WP REST /wp-json/wp/v2/types  → reads docs.has_archive slug   (language-agnostic)
//   2. BetterDocs REST API           → reads docs_slug from settings
//   3. Fetch first /wp-json/wp/v2/docs entry → derive archive from its permalink
//   4. DOM class scan on current page → finds [class*="betterdocs"] elements
//   5. Scored link scan              → ranks same-origin anchors by BetterDocs signals

// ─── UI helpers ──────────────────────────────────────────────────────────────

const $ = (id) => document.getElementById(id);

function setStep(id, state) {
  const el = $(id);
  if (el) el.className = "step " + state;
}

function showResult(url, via) {
  $("steps").style.display = "none";
  $("result").style.display = "block";
  $("resultUrl").textContent = url;
  $("resultVia").textContent = "Found via: " + via;
  $("status").textContent = "";
}

function showError(msg) {
  $("steps").style.display = "none";
  $("errorBox").style.display = "block";
  $("errorBox").textContent = msg;
  $("status").textContent = "";
}

// ─── Background fetch helpers ────────────────────────────────────────────────

function bgFetchJson(url) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "FETCH_URL", url }, (response) => {
      resolve(response || { ok: false, error: "No response" });
    });
  });
}

function bgFetchHtml(url) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "FETCH_HTML", url }, (response) => {
      resolve(response || { ok: false, error: "No response" });
    });
  });
}

// ─── Verify: does a URL's HTML contain BetterDocs classes? ───────────────────

async function verifyBetterDocsPage(url) {
  const res = await bgFetchHtml(url);
  if (!res.ok || !res.html) return false;
  return /class=["']?betterdocs|\bbetterdocs-[a-z]/i.test(res.html);
}

// ─── Strategy 1: WP REST API — read has_archive slug ─────────────────────────
// /wp-json/wp/v2/types → docs.has_archive is a STRING slug when BetterDocs is active.
// e.g. "docs", "rent-to-own", "المستندات" — fully language-agnostic.
// NOTE: do NOT use _links.collection — that points back to the API endpoint itself.

async function tryWpRestTypes(origin) {
  const res = await bgFetchJson(origin + "/wp-json/wp/v2/types");
  if (!res.ok || !res.data) return null;

  const docsType = res.data.docs;
  if (!docsType) return null;

  if (typeof docsType.has_archive === "string" && docsType.has_archive.trim()) {
    return origin + "/" + docsType.has_archive.trim();
  }

  return null;
}

// ─── Strategy 2: BetterDocs REST settings ────────────────────────────────────

async function tryBetterDocsApi(origin) {
  const res = await bgFetchJson(origin + "/wp-json/betterdocs/v1/settings");
  if (res.ok && res.data) {
    const slug = res.data.docs_slug || res.data.archive_slug || res.data.slug;
    if (slug) return origin + "/" + slug;
  }
  return null;
}

// ─── Strategy 3: First doc permalink → archive root ──────────────────────────

async function tryFirstDocPermalink(origin) {
  const res = await bgFetchJson(origin + "/wp-json/wp/v2/docs?per_page=1&_fields=link");
  if (!res.ok || !Array.isArray(res.data) || res.data.length === 0) return null;

  const docLink = res.data[0].link;
  if (!docLink) return null;

  const url = new URL(docLink);
  const segments = url.pathname.replace(/\/$/, "").split("/").filter(Boolean);
  if (segments.length >= 2) {
    return origin + "/" + segments.slice(0, -1).join("/");
  }
  return null;
}

// ─── Strategies 4 & 5: Injected content script ───────────────────────────────

function contentScriptDetect() {
  const origin = window.location.origin;

  // 4. Direct BetterDocs class element scan
  const bdEls = Array.from(
    document.querySelectorAll('[class*="betterdocs"], [id*="betterdocs"], [data-betterdocs]')
  );
  for (const el of bdEls) {
    const anchor = el.tagName === "A" ? el : el.querySelector("a");
    if (anchor && anchor.href && anchor.href.startsWith(origin)) {
      const seg = new URL(anchor.href).pathname.split("/").filter(Boolean)[0];
      if (seg) return { found: true, url: origin + "/" + seg, via: "betterdocs-class" };
    }
  }

  // 5. Scored anchor scan
  const SIGNALS = [
    { test: (a) => /betterdocs/i.test(a.className + " " + a.id), score: 20 },
    { test: (a) => Array.from(a.attributes).some(attr => /betterdocs/.test(attr.name + attr.value)), score: 15 },
    { test: (a) => /doc(s|umentation)|knowledge.?base|help.?center/i.test((a.getAttribute("aria-label") || "") + a.title), score: 10 },
    { test: (a) => /\b(docs|documentation|knowledge\s*base|help\s*center)\b/i.test(a.textContent.trim()), score: 8 },
    { test: (a) => !!a.closest("nav, header, [role=navigation], .menu, .navbar, .site-nav"), score: 5 },
    { test: (a) => { try { return new URL(a.href).pathname.replace(/\/$/, "").split("/").filter(Boolean).length === 1; } catch { return false; } }, score: 3 },
  ];

  let best = null, bestScore = 0;
  for (const a of document.querySelectorAll("a[href]")) {
    try { if (new URL(a.href).origin !== origin) continue; } catch { continue; }
    let score = 0;
    for (const s of SIGNALS) { try { if (s.test(a)) score += s.score; } catch { } }
    if (score > bestScore) { bestScore = score; best = a; }
  }

  if (best && bestScore >= 8) {
    const seg = new URL(best.href).pathname.split("/").filter(Boolean)[0] || "";
    return { found: true, url: seg ? origin + "/" + seg : best.href, via: "scored-link-scan" };
  }

  return { found: false };
}

// ─── Main flow ────────────────────────────────────────────────────────────────

document.getElementById("findBtn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const origin = new URL(tab.url).origin;

  $("findBtn").disabled = true;
  $("result").style.display = "none";
  $("errorBox").style.display = "none";
  $("steps").style.display = "flex";
  ["s1","s2","s3","s4","s5"].forEach(s => setStep(s, ""));

  // Step 1 — WP REST types / has_archive
  setStep("s1", "active");
  const wpSlugUrl = await tryWpRestTypes(origin);
  if (wpSlugUrl) {
    setStep("s1", "done");
    showResult(wpSlugUrl, "WordPress REST API (has_archive slug)");
    chrome.tabs.create({ url: wpSlugUrl });
    $("findBtn").disabled = false;
    return;
  }
  setStep("s1", "failed");

  // Step 2 — BetterDocs REST settings
  setStep("s2", "active");
  const bdApiUrl = await tryBetterDocsApi(origin);
  if (bdApiUrl) {
    setStep("s2", "done");
    showResult(bdApiUrl, "BetterDocs REST API settings");
    chrome.tabs.create({ url: bdApiUrl });
    $("findBtn").disabled = false;
    return;
  }
  setStep("s2", "failed");

  // Step 3 — First doc permalink
  setStep("s3", "active");
  const firstDocUrl = await tryFirstDocPermalink(origin);
  if (firstDocUrl) {
    setStep("s3", "done");
    showResult(firstDocUrl, "first doc permalink");
    chrome.tabs.create({ url: firstDocUrl });
    $("findBtn").disabled = false;
    return;
  }
  setStep("s3", "failed");

  // Steps 4 & 5 — DOM scan
  setStep("s4", "active");
  setStep("s5", "active");
  let domResult = null;
  try {
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: contentScriptDetect,
    });
    domResult = injection?.result;
  } catch (e) {}

  if (domResult?.found) {
    setStep("s4", "done");
    setStep("s5", "done");
    showResult(domResult.url, domResult.via);
    chrome.tabs.create({ url: domResult.url });
    $("findBtn").disabled = false;
    return;
  }

  setStep("s4", "failed");
  setStep("s5", "failed");
  showError(
    "No BetterDocs page found on this site.\n\n" +
    "Make sure you're on a WordPress site using the BetterDocs plugin, " +
    "and try clicking from the homepage."
  );
  $("findBtn").disabled = false;
});
