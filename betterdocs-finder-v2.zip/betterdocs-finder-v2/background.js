// background.js — Service Worker
// Handles cross-origin fetch calls from the popup via message passing.

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {

  // JSON fetch (REST API calls)
  if (message.type === "FETCH_URL") {
    fetch(message.url, {
      method: "GET",
      headers: { "Accept": "application/json" },
      signal: AbortSignal.timeout(6000),
    })
      .then(async (res) => {
        if (!res.ok) { sendResponse({ ok: false, status: res.status }); return; }
        const data = await res.json();
        sendResponse({ ok: true, data });
      })
      .catch((err) => sendResponse({ ok: false, error: err.message }));

    return true;
  }

  // HTML fetch (verify betterdocs classes on candidate page)
  if (message.type === "FETCH_HTML") {
    fetch(message.url, {
      method: "GET",
      headers: { "Accept": "text/html" },
      signal: AbortSignal.timeout(8000),
    })
      .then(async (res) => {
        if (!res.ok) { sendResponse({ ok: false, status: res.status }); return; }
        const html = await res.text();
        sendResponse({ ok: true, html });
      })
      .catch((err) => sendResponse({ ok: false, error: err.message }));

    return true;
  }
});
